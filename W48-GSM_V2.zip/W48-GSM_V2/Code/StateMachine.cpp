#include "Arduino.h"
#include "StateMachine.h"
#include "Relay.h"
#include "Buzzer.h"
#include "GroundKey.h"
#include "Hook.h"
#include "Dialer.h"
#include "Bell.h"
#include "SDAudio.h"
#include "SIM800L.h"
#include "Phonebook.h"
#include "StateMachine.h"
#include "PinConfig.h"
#include "SelfCall.h"

// #define DEBUG_STATEMACHINE

#ifndef DEBUG_STATEMACHINE

#ifdef DEBUG_PRINTLN
#undef DEBUG_PRINTLN
#define DEBUG_PRINTLN(a)
#undef DEBUG_PRINT
#define DEBUG_PRINT(a)
#endif

#endif

phonestate PhoneState = WAITING;
// messages explained:
// ring_up: SIM800 raises ring-signal
// ring_down: SIM800 lowers ring-signal
// offhook: hook-contact indicates a lifted hook
// offhook: hook-contact indicates a lowered hook
// quit: SIM800 sends a "NO CARRIER" message during a call, partner may have hung up. OR: SIM800 sends 2 "BUSY" message
// dial: a cipher has been dialed with the plate
// dialfinish: some time after last cipher dialing expired
// connect: SIM800L indicates a "MO CONNECTED" message, the call is established

const phonestate statetransfer[6][8] =
{	/*					ring_up 0		ring_down 1		offhook 2		onhook 3	quit 4			dial 5			dialfinish 6	connect 7 */
	/*0 WAITING */		RINGING,		WAITING,		DIALING,		WAITING,	WAITING,		WAITING,		WAITING,		WAITING,
	/*1 RINGING*/		RINGING,		WAITING,		TALKING,		RINGING,	RINGING,		RINGING,		RINGING,		RINGING,
	/*2 TALKING*/		TALKING,		TALKING,		TALKING,		WAITING,	DISCONNECTED,	TALKING,		TALKING,		TALKING,
	/*3 DISCONNECTED*/	DISCONNECTED,	DISCONNECTED,	DISCONNECTED,	WAITING,	DISCONNECTED,	DISCONNECTED,	DISCONNECTED,	DISCONNECTED,
	/*4 DIALING*/		DIALING,		DIALING,		DIALING,		WAITING,	DIALING,		DIALING,		CONNECTING,		DIALING,
	/*5 CONNECTING*/	CONNECTING,		CONNECTING,		CONNECTING,		WAITING,	DISCONNECTED,	DIALING,		CONNECTING,		TALKING
};

void Morse(int code)
{
	code += 1; // avoid null element
	if (code <= 5)
	{
		for (int i = 0; i < code; ++i)
		{
			BuzzerOn(40);
			delay(50);
		}
	}
	else
	{
		for (int i = 0; i < code; ++i)
		{
			BuzzerOn(100);
			delay(50);
		}
	}
}

void Impossible(String txt, phonestate s, stateevent e)
{
	DEBUG_PRINTLN(txt + " impossible");
	// morse illegal state/event transit
	Morse(s);
	delay(400);
	Morse(e);
}

#define DIALPAUSE_MAX 4500
String dialstring;
unsigned long lastDialTime;

//#pragma region WAITING
void WAIT_ringup()
{
	DEBUG_PRINTLN("WAIT_ringup");
	StartRingBell();	// just start the bell
}

void WAIT_ringdown()
{
	Impossible("WAIT_ringdown", WAITING, ring_down);
}

void WAIT_offhook()
{
	DEBUG_PRINTLN("WAIT_offhook");
	if (SelfCallMode)
		CancelSelfCall();

	StartFreizeichen();
	dialstring = "";
	lastDialTime = millis();
}

void WAIT_onhook()
{
	DEBUG_PRINTLN("WAIT_onhook");
	// Maybe phone was offhook at the time booting
	// Do nothing
}

void WAIT_quit()
{
	DEBUG_PRINTLN("WAIT_quit");
	// Do nothing
}

void WAIT_dial()
{
	DEBUG_PRINTLN("WAIT_dial");
	int num;
	PopDialedNumber(&num); // flush the cipher
}

void WAIT_dialfinish()
{
	Impossible("WAIT_dialfinish", WAITING, dialfinish);
}

void WAIT_connect()
{
	Impossible("WAIT_connect", WAITING, connected);
}

//#pragma endregion

//#pragma region RINGING

void RING_ringup()
{
	if (SelfCallMode)
		CancelSelfCall();
	//Impossible("RING_ringup");
}

void RING_ringdown()
{
	DEBUG_PRINTLN("RING_ringdown");
	CancelRingBell();
}

void RING_offhook()
{
	DEBUG_PRINTLN("RING_offhook");
	CancelRingBell();
	if (SelfCallMode)
		StartSelfCallAudio();
	else
		AcceptCall();
}

void RING_onhook()
{
	Impossible("RING_onhook", RINGING, onhook);
}

void RING_quit()
{
	DEBUG_PRINTLN("RING_quit");
	// Do nothing
}

void RING_dial()
{
	DEBUG_PRINTLN("RING_dial");
	int num;
	PopDialedNumber(&num); // flush the cipher
}

void RING_dialfinish()
{
	DEBUG_PRINTLN("RING_dialfinish");
	Impossible("RING_dialfinish", RINGING, dialfinish);
}

void RING_connect()
{
	Impossible("RING_connect", RINGING, connected);
}

//#pragma endregion

//#pragma region TALKING

void TALK_ringup()
{
	if (SelfCallMode)
		CancelSelfCall();
	CancelCall();
	// Impossible("TALK_ringup");
}

void TALK_ringdown()
{
	DEBUG_PRINTLN("TALK_ringdown");
	// Do nothing. Its the usual behaviour if a call is answered: the ringing ends
}

void TALK_offhook()
{
	Impossible("TALK_offhook", TALKING, offhook);
}

void TALK_onhook()
{
	DEBUG_PRINTLN("TALK_onhook");
	if (SelfCallMode)
	{
		if (AudioOn)
			CancelSelfCall();
		else
			StartSelfCallTimer();
	}
	else if (AudioOn)
	{
		StopAudio();
	}
	else
		CancelCall();
}

void TALK_quit()
{	// Caller ends call
	DEBUG_PRINTLN("TALK_quit");
	if (AudioOn)
	{
		StopAudio();
	}
	else
		CancelCall();

	StartBesetztzeichen();
}

void TALK_dial()
{
	DEBUG_PRINTLN("TALK_dial");
	int num;
	PopDialedNumber(&num); // flush the cipher
}

void TALK_dialfinish()
{
	Impossible("TALK_dialfinish", TALKING, dialfinish);
}

void TALK_connect()
{
	Impossible("TALK_connect", TALKING, connected);
}

//#pragma endregion

//#pragma region DISCONNECTED

void DISC_ringup()
{
	if (SelfCallMode)
		CancelSelfCall();

	DEBUG_PRINTLN("DISC_ringup");
	CancelCall();
}

void DISC_ringdown()
{
	DEBUG_PRINTLN("DISC_ringdown");
	// Do nothing
}

void DISC_offhook()
{
	Impossible("DISC_offhook", DISCONNECTED, offhook);
}

void DISC_onhook()
{
	DEBUG_PRINTLN("DISC_onhook");
	CancelBesetztzeichen();
}

void DISC_quit()
{
	DEBUG_PRINTLN("DISC_quit");
	// Do nothing
}

void DISC_dial()
{
	DEBUG_PRINTLN("DISC_dial");
	int num;
	PopDialedNumber(&num); // flush the cipher
}

void DISC_dialfinish()
{
	DEBUG_PRINTLN("DISC_dialfinish");
	Impossible("DISC_dialfinish", DISCONNECTED, dialfinish);
}

void DISC_connect()
{
	Impossible("DISC_connect", DISCONNECTED, connected);
}

//#pragma endregion

//#pragma region DIALING

void DIAL_ringup()
{
	if (SelfCallMode)
		CancelSelfCall();

	DEBUG_PRINTLN("DIAL_ringup");
	CancelCall();
}

void DIAL_ringdown()
{
	DEBUG_PRINTLN("DIAL_ringdown");
	// Nothing to do.
}

void DIAL_offhook()
{
	Impossible("DIAL_offhook", DIALING, offhook);
}

void DIAL_onhook()
{
	DEBUG_PRINTLN("DIAL_onhook");
	CancelFreizeichen();
}

void DIAL_quit()
{
	DEBUG_PRINTLN("DIAL_quit");
	// Do nothing
}

void DIAL_dial()
{
	DEBUG_PRINTLN("DIAL_dial");
	lastDialTime = millis();

	int num;
	if (!PopDialedNumber(&num))
	{
		DEBUG_PRINTLN("No number on dial event!");
		return;
	}

	DEBUG_PRINT("Dialed:"); DEBUG_PRINTLN(num);

	if (GroundKeyEvent == groundkeylongevent)
	{	// Save last dialed number in memory under index of just dialed number
		BuzzerAsyncBeeps(3);
		GroundKeyEvent = groundkeynoevent;
		String aNum = ReadFromPhoneBook(LAST_DIALED);
		SaveInPhoneBook(aNum, num);

		// Freizeichen remains enabled, user may dial immediately any number or do a quick dial
		return;
	}
	if (GroundKeyEvent == groundkeyshortevent)
	{	// quick dial
		CancelFreizeichen();
		GroundKeyEvent = groundkeynoevent;
		dialstring = ReadFromPhoneBook(num);
		QueueEvent(dialfinish);
		return;
	}

	CancelFreizeichen();
	dialstring += (char)(num + '0');
	lastDialTime = millis();
}

void DIAL_dialfinish()
{
	DEBUG_PRINTLN("DIAL_dialfinish:" + dialstring);
	if (dialstring.startsWith("123") && (dialstring.length() == 4))
	{
		char c = dialstring.charAt(3);
		c -= '0';
		StartAudio(c);
		DEBUG_PRINTLN("Override state to TALKING");
		PhoneState = TALKING;
	}
	else if (dialstring.startsWith("321") && (dialstring.length() == 4))
	{
		char c = dialstring.charAt(3);
		c -= '0';
		InitSelfCall(c);
		DEBUG_PRINTLN("Override state to TALKING");
		PhoneState = TALKING;
	}
	else
	{
		ConnectToNumber(dialstring);
	}
	SaveInPhoneBook(dialstring, LAST_DIALED);
}

void DIAL_connect()
{
	Impossible("DIAL_connect", DIALING, connected);
}

//#pragma endregion

//#pragma region CONNECTING

void CONN_ringup()
{
	if (SelfCallMode)
		CancelSelfCall();

	Impossible("CONN_ringup", CONNECTING, ring_up);
}

void CONN_ringdown()
{
	Impossible("CONN_ringdown", CONNECTING, ring_down);
}

void CONN_offhook()
{
	Impossible("CONN_offhook", CONNECTING, offhook);
}

void CONN_onhook()
{
	DEBUG_PRINTLN("CONN_onhook");
	CancelCall();
	delay(300);
	CancelBesetztzeichen();
}

void CONN_quit()
{
	DEBUG_PRINTLN("CONN_quit");
	CancelCall();
	StartBesetztzeichen();
}

void CONN_dial()
{
	DEBUG_PRINTLN("CONN_dial");
	CancelCall();
	lastDialTime = millis();
	QueueEvent(dial);
}

void CONN_dialfinish()
{
	Impossible("CONN_dialfinish", CONNECTING, dialfinish);
}

void CONN_connect()
{
	DEBUG_PRINTLN("CONN_connect");
	// Do nothing, just switch state
}

//#pragma endregion

const statefct statemachine[6][8] =
{	//						ring_up 0	ring_down 1		offhook 2		onhook 3		quit 4		dial 5		dialfinish 6		connect 7
	/*0 WAITING */      { WAIT_ringup,	WAIT_ringdown,	WAIT_offhook,	WAIT_onhook,	WAIT_quit,	WAIT_dial,	WAIT_dialfinish,	WAIT_connect},
	/*1 RINGING*/       { RING_ringup,	RING_ringdown,	RING_offhook,	RING_onhook,	RING_quit,	RING_dial,	RING_dialfinish,	RING_connect},
	/*2 TALKING*/       { TALK_ringup,	TALK_ringdown,	TALK_offhook,	TALK_onhook,	TALK_quit,	TALK_dial,	TALK_dialfinish,	TALK_connect},
	/*3 DISCONNECTED*/  { DISC_ringup,	DISC_ringdown,	DISC_offhook,	DISC_onhook,	DISC_quit,	DISC_dial,	DISC_dialfinish,	DISC_connect},
	/*4 DIALING*/       { DIAL_ringup,	DIAL_ringdown,	DIAL_offhook,	DIAL_onhook,	DIAL_quit,	DIAL_dial,	DIAL_dialfinish,	DIAL_connect},
	/*5 CONNECTING*/    { CONN_ringup,	CONN_ringdown,	CONN_offhook,	CONN_onhook,	CONN_quit,	CONN_dial,	CONN_dialfinish,	CONN_connect}
};

void CheckEventDialFinished()
{
	if ((PhoneState == DIALING) && ((millis() - lastDialTime) > DIALPAUSE_MAX) && (dialstring.length() > 2))
		QueueEvent(dialfinish);
}


portMUX_TYPE eventMux = portMUX_INITIALIZER_UNLOCKED;
#define EVENTQUEUESIZE 10
stateevent eventqueue[EVENTQUEUESIZE];
int eventqueuereadidx = 0;
int eventqueuewriteidx = 0;
int eventsinqueue = 0;

stateevent UnQueueEvent()
{
	stateevent ret = noevent;
	portENTER_CRITICAL(&eventMux);
	if (eventsinqueue)
	{
		ret = eventqueue[eventqueuereadidx];
		eventsinqueue--;
		eventqueuereadidx++;
		if (eventqueuereadidx == EVENTQUEUESIZE)
			eventqueuereadidx = 0;
	}
	portEXIT_CRITICAL(&eventMux);
	return ret;
}

void QueueEvent(stateevent newevent)
{
	DEBUG_PRINTLN("Queue " + eventNoToText(newevent));
	portENTER_CRITICAL(&eventMux);
	if (eventsinqueue < EVENTQUEUESIZE)
	{
		eventqueue[eventqueuewriteidx] = newevent;
		eventsinqueue++;
		eventqueuewriteidx++;
		if (eventqueuewriteidx == EVENTQUEUESIZE)
			eventqueuewriteidx = 0;
	}
	portEXIT_CRITICAL(&eventMux);
}

#ifdef DEBUG_STATEMACHINE

String eventNoToText(stateevent e)
{
	switch (e)
	{

	case ring_up:
		return "ring_up";
		break;
	case  ring_down:
		return "ring_down";
		break;
	case  offhook:
		return "offhook";
		break;
	case  onhook:
		return "onhook";
		break;
	case quit:
		return "quit";
		break;
	case  dial:
		return "dial";
		break;
	case  dialfinish:
		return "dialfinish";
		break;
	case  connected:
		return "connected";
		break;
	case  noevent:
		return "noevent";
		break;
	}
	return "<unknown event>";
}

String stateNoToText(phonestate s)
{
	switch (s)
	{
	case WAITING:
		return "WAITING";
		break;
	case RINGING:
		return "RINGING";
		break;
	case TALKING:
		return "TALKING";
		break;
	case DISCONNECTED:
		return "DISCONNECTED";
		break;
	case DIALING:
		return "DIALING";
		break;
	case CONNECTING:
		return "CONNECTING";
		break;
	}
	return "<unknown state>";
}

#endif

void StateMachine()
{
	stateevent evnt = UnQueueEvent();
	if (evnt == noevent)
		return;

	DEBUG_PRINTLN("Handling " + eventNoToText(evnt) + " at " + stateNoToText(PhoneState));
	statefct fct = statemachine[PhoneState][evnt];
	PhoneState = statetransfer[PhoneState][evnt];
	fct();
}
