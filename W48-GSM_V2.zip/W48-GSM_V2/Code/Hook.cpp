#include "Arduino.h"
#include "PinConfig.h"
#include "StateMachine.h"
#include "Hook.h"
#include "GroundKey.h"

// #define DEBUG_HOOK

#ifndef DEBUG_HOOK

#ifdef DEBUG_PRINTLN
#undef DEBUG_PRINTLN
#define DEBUG_PRINTLN(a)
#undef DEBUG_PRINT
#define DEBUG_PRINT(a)
#endif

#endif

#if defined DEBUG_HOOK
unsigned long lastIrqHook = 0;
#endif

#define DEBOUNCE_HOOK 50000 // In tests with this contact, I found a bouncing of up to 18000 microseconds.
esp_timer_handle_t timerHook;

void IRAM_ATTR ISR_Hook()
{
#ifdef DEBUG_HOOK
	int pin = digitalRead(PIN_HOOK);
	unsigned long now = micros();
	unsigned long diff = now - lastIrqHook;
	lastIrqHook = now;
	if (pin)
		DEBUG_PRINT(String(diff) + " H+ ");
	else
		DEBUG_PRINT(String(diff) + " H- ");
#endif

	esp_timer_stop(timerHook);
	esp_timer_start_once(timerHook, DEBOUNCE_HOOK);
}

void OnTimerHook(void* arg)
{
	int pin = digitalRead(PIN_HOOK);

#ifdef DEBUG_HOOK
	unsigned long now = micros();
	unsigned long diff = now - lastIrqHook;
	lastIrqHook = now;
	if (pin == HOOK_ONHOOK)
		DEBUG_PRINTLN(String(diff) + " Ht+");
	else
		DEBUG_PRINTLN(String(diff) + " Ht-");
#endif

	if (pin == HOOK_ONHOOK)
	{
		GroundKeyEvent = groundkeynoevent;
		QueueEvent(onhook);
	}
	else
		QueueEvent(offhook);
}

void Setup_Hook()
{
	esp_timer_create_args_t timerConfigHook;
	timerConfigHook.arg = NULL;
	timerConfigHook.callback = OnTimerHook;
	timerConfigHook.dispatch_method = ESP_TIMER_TASK;
	timerConfigHook.name = "Hook";

	if (esp_timer_create(&timerConfigHook, &timerHook) != ESP_OK)
	{
		DEBUG_PRINTLN("timerHook create failed.");
	}

	pinMode(PIN_HOOK, INPUT_PULLUP);
	delay(50); // debounce, maybe not necessary
	int pin = digitalRead(PIN_HOOK);
	if (pin == HOOK_OFFHOOK)	// powered on while hook is off
		QueueEvent(offhook);

	attachInterrupt(digitalPinToInterrupt(PIN_HOOK), ISR_Hook, CHANGE);
}

