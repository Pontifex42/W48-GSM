#pragma once

void Setup_SIM800L();

void AcceptCall();
void CancelCall();
void ConnectToNumber(String dialstring);

void IRAM_ATTR ISR_Besetztzeichen();
void StartBesetztzeichen();
void CancelBesetztzeichen();

void IRAM_ATTR ISR_Freizeichen();
void StartFreizeichen();
void CancelFreizeichen();

