#include "Audio.h"
#include "SD.h"
#include "FS.h"
#include "PinConfig.h"
#include "Relay.h"
#include <SPI.h>

String files[10];

// #define DEBUG_AUDIO

#ifndef DEBUG_AUDIO

#ifdef DEBUG_PRINTLN
#undef DEBUG_PRINTLN
#define DEBUG_PRINTLN(a)
#undef DEBUG_PRINT
#define DEBUG_PRINT(a)
#endif

#endif

Audio audio;

bool AudioOn = false;

#define FILENAME_MAXLEN 100
void StartAudio(int num)
{
	DEBUG_PRINTLN("StartAudio " + String(num));
	if (files[num].length() < 1)
		return;

 	RelayOn();

	char charBuf[FILENAME_MAXLEN];
	files[num].toCharArray(&charBuf[0], FILENAME_MAXLEN);
	audio.connecttoFS(SD, &charBuf[0]);
	AudioOn = true;

	delay(50); // Give relay time to act
}

void StopAudio()
{
	if (!AudioOn)
		return;
	AudioOn = false;
	RelayOff();
}

// optional
void audio_info(const char* info)
{
	DEBUG_PRINTLN("info        ");
	DEBUG_PRINTLN(info);
}

void audio_id3data(const char* info)
{  //id3 metadata
	DEBUG_PRINTLN("id3data     ");
	DEBUG_PRINTLN(info);
}

void audio_eof_mp3(const char* info)
{  //end of file
	DEBUG_PRINTLN("eof_mp3     ");
	DEBUG_PRINTLN(info);
}

void audio_showstation(const char* info)
{
	DEBUG_PRINTLN("station     ");
	DEBUG_PRINTLN(info);
}

void audio_showstreaminfo(const char* info)
{
	DEBUG_PRINTLN("streaminfo  ");
	DEBUG_PRINTLN(info);
}

void audio_showstreamtitle(const char* info)
{
	DEBUG_PRINTLN("streamtitle ");
	DEBUG_PRINTLN(info);
}

void audio_bitrate(const char* info)
{
	DEBUG_PRINTLN("bitrate     ");
	DEBUG_PRINTLN(info);
}

void audio_commercial(const char* info)
{  //duration in sec
	DEBUG_PRINTLN("commercial  ");
	DEBUG_PRINTLN(info);
}

void audio_icyurl(const char* info)
{  //homepage
	DEBUG_PRINTLN("icyurl      ");
	DEBUG_PRINTLN(info);
}

void audio_lasthost(const char* info)
{  //stream URL played
	DEBUG_PRINTLN("lasthost    ");
	DEBUG_PRINTLN(info);
}

void audio_eof_speech(const char* info)
{
	DEBUG_PRINTLN("eof_speech  ");
	DEBUG_PRINTLN(info);
}

void LoopAudio()
{
	if (AudioOn)
		audio.loop();
}

void StartPlaying(const char* file)
{
	// audio.connecttoFS(SD, "seconds-CBR.mp3");
	audio.connecttoFS(SD, file);
	LoopAudio();
}

void EndPlaying()
{
	audio.stopSong();
}

void ScanOneFileName(File f)
{
	String name = f.name();

	DEBUG_PRINTLN(name);
	
	if (f.isDirectory())
		return;

	if (name.length() < 3)
		return;

	String s = name.substring(1); // skip leading '/'
	char charBuf[FILENAME_MAXLEN];
	s.toCharArray(charBuf, FILENAME_MAXLEN);
	int num = atoi(charBuf);

	if ((num == 0) && s[0] != '0')
		return;

	if ((num < 0) || (num > 9))
		return;

	DEBUG_PRINTLN("Adding file no " + String(num));
	files[num] = s;
}

void ScanDirectory(fs::FS& fs, const char* dirname, uint8_t levels)
{
	DEBUG_PRINTLN("Scanning directory");
	File root = fs.open(dirname);
	if (!root)
	{
		DEBUG_PRINTLN("Failed to open directory" + String(dirname));
		return;
	}

	if (!root.isDirectory())
	{
		DEBUG_PRINTLN("Not a directory");
		return;
	}

	File file = root.openNextFile();
	while (file)
	{
		ScanOneFileName(file);
		file = root.openNextFile();
	}
}

void SetupSDCardReader()
{
	pinMode(PIN_SPI_CS, OUTPUT);
	digitalWrite(PIN_SPI_CS, HIGH);
	SPI.begin(PIN_SPI_SCK, PIN_SPI_MISO, PIN_SPI_MOSI);

	if (!SD.begin(PIN_SPI_CS))
	{
		DEBUG_PRINTLN("Card Mount Failed");
		return;
	}

	uint8_t cardType = SD.cardType();
	if (cardType == CARD_NONE)
	{
		DEBUG_PRINTLN("No SD card attached");
		return;
	}

	DEBUG_PRINT("SD Card Type: ");
	if (cardType == CARD_MMC)
	{
		DEBUG_PRINTLN("MMC");
	}
	else if (cardType == CARD_SD)
	{
		DEBUG_PRINTLN("SDSC");
	}
	else if (cardType == CARD_SDHC)
	{
		DEBUG_PRINTLN("SDHC");
	}
	else
	{
		DEBUG_PRINTLN("UNKNOWN CARD TYPE");
	}

	DEBUG_PRINT("SD Card Size:");
	DEBUG_PRINTLN(SD.cardSize() / (1024 * 1024));

	ScanDirectory(SD, "/", 0);
}

void Setup_SDAudio()
{
	SetupSDCardReader();

	audio.setPinout(PIN_I2S_BCLK, PIN_I2S_LRC, PIN_I2S_DOUT);
	audio.setVolume(10); // 0...21
	audio.forceMono(true);
}

