#pragma once

void Setup_GroundKey();
void CheckEventGroundkey();

typedef enum GroundKeyEvent_T
{
	groundkeynoevent,
	groundkeyshortevent,
	groundkeylongevent
}dGroundKeyEvent_T;

extern GroundKeyEvent_T GroundKeyEvent;
