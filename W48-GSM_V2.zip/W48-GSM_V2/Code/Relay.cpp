#include "Arduino.h"
#include "PinConfig.h"

void RelayOn()
{
	digitalWrite(PIN_RELAY, HIGH);
}

void RelayOff()
{
	digitalWrite(PIN_RELAY, LOW);
}

void Setup_Relay()
{
	pinMode(PIN_RELAY, OUTPUT);
	RelayOff();
}
