#pragma once

void Setup_SDAudio();
void LoopAudio();
void StartAudio(int num);
void StopAudio();
extern bool AudioOn;
