#pragma once
#include "Arduino.h"

#define LAST_DIALED 1
#define LAST_CALLER 2

void Setup_Phonebook();
bool SaveInPhoneBook(String number, uint8_t idx);
String ReadFromPhoneBook(uint8_t idx);

