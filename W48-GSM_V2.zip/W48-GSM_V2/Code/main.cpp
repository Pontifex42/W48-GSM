/* This is project "FeTap GSM V2.0"
	Created 11/2021 by Thorsten Hartwig.
	Feel free to contact me: fetap612_V2@hartwig.org

	There is no license. Feel free to do anything with this software.
	If you find bugs, I'd be appreciated if I get a mail.
	And, of course, if you do this project, please send a picture of the result.
*/

/* 
Section for wishes to the software
- Warning on battery low before shutting down
- PIN audio message, if PIN is necessary
- wakeup of esp32 on any switch event, saving energy
- sleep mode of SIM800L which accepts incoming calls, to save energy
- support OTA update using "button pressed at boot" signal
declined requirements:
- WiFi and web interface (due to power consumption)
- faster reaction on dialing-end (how should that work?)
- better control of SIM module

Section for wishes to the PCB-design
- space at the nose of hook contact 
- move charge connector 9.0mm left for easier access from outside
*/


#include <Arduino.h>
#include "PinConfig.h"
#include "Relay.h"
#include "Buzzer.h"
#include "GroundKey.h"
#include "Hook.h"
#include "Dialer.h"
#include "Bell.h"
#include "SDAudio.h"
#include "SIM800L.h"
#include "Phonebook.h"
#include "StateMachine.h"
#include <WiFi.h>
#include "SelfCall.h"

void setup()
{
	Serial.begin(115200);
	setCpuFrequencyMhz(160);
	WiFi.mode(WIFI_OFF);
	WiFi.setSleep(true);
	btStop();
	Setup_Phonebook();
	Setup_Buzzer();
	Setup_Bell();
	Setup_Relay();
	Setup_SIM800L();
	Setup_GroundKey();
	Setup_Hook();
	Setup_Dialer();
	Setup_SDAudio();
	Setup_SelfCall();
}

void SaveCallerNumber(String rcvstr)
{
	// received string should be something like this
	// +CLIP: "+491721234567",145,"",0,"",0

	rcvstr.remove(0, String("+CLIP: \"").length());
	int idx = rcvstr.indexOf('\"');
	if (idx < 3) // no numbers with length less than 3 ciphers
		return;
	rcvstr = rcvstr.substring(0, idx);

	if (rcvstr.charAt(0) == '+')
		rcvstr = "00" + rcvstr.substring(1, rcvstr.length());

	for (int i = 0; i < rcvstr.length(); ++i)
		if ((rcvstr.charAt(i) < '0') || (rcvstr.charAt(i) > '9'))
			return;
	SaveInPhoneBook(rcvstr, LAST_CALLER);
}

void CheckEventSIM800()
{
	static String rcvstr;
	// while (Serial.available()) // to control the SIM module directly from a monitor/terminal, uncomment this
	// {
	// 	Serial2.write(Serial.read());//Forward what SIM800 serial received to monitor serial port
	// }
	while (Serial2.available())
	{
		uint8_t c = Serial2.read();
		if (isprint(c) || (c == '\r') || (c == '\n'))
		{
			if ((c != '\r') && (c != '\n'))
				rcvstr += (char)c;
			if (c == '\n')
			{
				if (!rcvstr.equals("") && !rcvstr.equals("OK") && !rcvstr.equals("RING") && !rcvstr.startsWith("+SIMTONE"))
				{
					DEBUG_PRINTLN(rcvstr);
				}
				if (rcvstr.startsWith("+CLIP:") && ((PhoneState == RINGING) || (PhoneState == WAITING)))
					SaveCallerNumber(rcvstr);
				else if (rcvstr.equals("NO CARRIER") && (PhoneState == TALKING))
					QueueEvent(quit);
				else if (rcvstr.equals("BUSY") && (PhoneState == CONNECTING))
					QueueEvent(quit);
				else if (rcvstr.equals("MO CONNECTED") && (PhoneState == CONNECTING))
					QueueEvent(connected);
				rcvstr = "";
			}
		}
		else
		{
			DEBUG_PRINTLN('<' + String(c) + '>');
		}
	}
}

void loop()
{
	LoopAudio();

	CheckEventSIM800();

	CheckEventGroundkey();

	CheckEventDialFinished();

	StateMachine();
}

