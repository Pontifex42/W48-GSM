#include "Arduino.h"
#include "PinConfig.h"
#include "StateMachine.h"
#include "SDAudio.h"
#include "Buzzer.h"

//#define DEBUG_SELFCALL
#ifndef DEBUG_SELFCALL

#ifdef DEBUG_PRINTLN
#undef DEBUG_PRINTLN
#define DEBUG_PRINTLN(a)
#undef DEBUG_PRINT
#define DEBUG_PRINT(a)
#endif

#endif


esp_timer_handle_t timerSelfCall;
#define SELFCALL_TIME 8000000 // 9 seconds

bool SelfCallMode = false;
int SelfCallMusic = 0;

void InitSelfCall(int c)
{
	DEBUG_PRINTLN("InitSelfCall " + String(c));
	SelfCallMusic = c;
	SelfCallMode = true;
	BuzzerAsyncBeeps(3);
}

void StartSelfCallTimer()
{
	DEBUG_PRINTLN("StartSelfCall");
	if (!SelfCallMode)
		return;

	esp_timer_stop(timerSelfCall);
	esp_timer_start_once(timerSelfCall, SELFCALL_TIME);
}

void CancelSelfCall()
{
	DEBUG_PRINTLN("CancelSelfCall");
	esp_timer_stop(timerSelfCall);
	SelfCallMode = false;
	StopAudio();
}

void OnTimerSelfCall(void* arg)
{
	DEBUG_PRINTLN("OnTimerSelfCall");
	if (PhoneState != WAITING)
	{
		CancelSelfCall();
		return;
	}
	QueueEvent(ring_up);
}

void StartSelfCallAudio()
{
	DEBUG_PRINTLN("StartSelfCallAudio");
	StartAudio(SelfCallMusic);
}

void Setup_SelfCall()
{
	esp_timer_create_args_t timerConfigSelfCall;
	timerConfigSelfCall.arg = NULL;
	timerConfigSelfCall.callback = OnTimerSelfCall;
	timerConfigSelfCall.dispatch_method = ESP_TIMER_TASK;
	timerConfigSelfCall.name = "SelfCall";

	if (esp_timer_create(&timerConfigSelfCall, &timerSelfCall) != ESP_OK)
	{
		DEBUG_PRINTLN("timerSelfCall create failed.");
	}
}