#pragma once

void Setup_Hook();
